# NovaPay frontend

Static HTML/CSS/JavaScript frontend for a wallet application. Designed to deploy to Vercel from a Git repository and to connect to a Python API.

## Included pages

- `index.html` — marketing landing page
- `auth.html` — login and account creation
- `app.html` — wallet dashboard with overview, transactions, send money, cards, settings, and help sections
- `css/styles.css` — shared responsive dark fintech styling
- `js/config.js` — API origin and demo mode
- `js/api.js` — API adapter
- `js/auth.js` — login/register interactions
- `js/app.js` — dashboard UI, demo transactions, transfer form, settings, CSV export

## Deploy to Vercel

1. Copy the contents of this folder into the root of your existing Git project.
2. Keep the folders and filenames as shown.
3. Commit and push:
   ```bash
   git add .
   git commit -m "Build NovaPay wallet frontend"
   git push
   ```
4. For a static site, use the project root as the Vercel Root Directory, with no build command and no output directory override. If Vercel is already configured for a framework, update those settings as needed.

## Connect your Python backend

Edit `js/config.js`:
```js
window.NOVAPAY_CONFIG = {
  API_BASE_URL: "https://your-api-domain.example/api",
  DEMO_MODE: false
};
```
For local development, use your actual local API address, for example `http://127.0.0.1:8000/api`.

The current adapter assumes these example endpoints. Change `js/api.js` to match your Python routes and response shapes:

| Method | Example endpoint | Expected purpose |
| --- | --- | --- |
| POST | `/auth/login` | Accept `{ email, password }`; returns access token or secure cookie |
| POST | `/auth/register` | Accept `{ name, email, password }` |
| POST | `/auth/logout` | End session |
| GET | `/auth/me` | Current authenticated user |
| GET | `/wallet` | Wallet balance and currency |
| GET | `/transactions` | Transaction list |
| POST | `/transfers` | Submit a transfer request |
| PATCH | `/profile` | Update profile |
| POST | `/support/tickets` | Create a support request |

The UI mapping in `js/app.js` expects broadly:
- `/auth/me`: `{ "name": "Alex Morgan", "email": "alex@example.com" }`
- `/wallet`: `{ "balance": 12480.5, "currency": "USD" }`
- `/transactions`: array of objects with `id`, `description`, `category` or `type`, `created_at` or `date`, `direction` or `type`, `status`, `amount`

## Important security notes before production

- This package is frontend scaffolding, not a complete financial system.
- Never put database credentials, secret keys, signing keys, or payment provider secrets in browser code.
- Prefer secure, HttpOnly, SameSite cookies for browser sessions. If your API uses cookies, configure CSRF protection. The example adapter also supports a bearer token response for prototyping, but storing access tokens in web storage is not the preferred production pattern for sensitive wallet apps.
- Configure CORS on the Python backend to allow only your frontend origin.
- Validate all fields and enforce authentication, authorization, transfer limits, idempotency, and fraud checks on the backend. Never trust a balance or transfer amount computed by the browser.
- Use HTTPS in production.
- Add real terms/privacy pages, password reset, email verification, account recovery, and appropriate compliance workflows before accepting real users.
- Demo mode uses sample data and a simulated session only. No real money moves, no real cards are issued, and no passwords are stored by this frontend.

## Local preview

Because `fetch` and browser routing can behave differently from `file://`, serve the folder using any static development server. One option:
```bash
python -m http.server 5500
```
Then open `http://127.0.0.1:5500`.
